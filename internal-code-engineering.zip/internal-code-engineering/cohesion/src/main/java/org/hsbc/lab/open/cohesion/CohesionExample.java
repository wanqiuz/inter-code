package org.hsbc.lab.open.cohesion;

import lombok.extern.slf4j.Slf4j;
import org.hsbc.lab.open.cohesion.config.RunnerConfig;
import org.hsbc.lab.open.cohesion.domain.dto.CkClassCohesionSourceDto;
import org.hsbc.lab.open.cohesion.domain.dto.CkFieldCohesionSourceDto;
import org.hsbc.lab.open.cohesion.domain.dto.CkMethodCohesionSourceDto;
import org.hsbc.lab.open.cohesion.domain.dto.CkVariableCohesionSourceDto;
import org.hsbc.lab.open.cohesion.runner.CkRunner;
import org.hsbc.lab.open.cohesion.util.pattern.FileFilterPatterns;

@Slf4j
public class CohesionExample {
    private static String PROJECT_ID = "openhabour-11223";
    private static String DATASET_ID = "code_engineering_dev";
    private static String ELASTICSEARCH_HOST = "localhost";
    private static Integer ELASTICSEARCH_PORT = 9200;
    private static String ELASTICSEARCH_SCHEME = "http";


    public static void main(String[] args) throws Exception {
        runCkField();
        runCkMethod();
        runCkClass();
        runCkVariable();
    }

    private static void runCkField() {
        RunnerConfig runnerConfig = RunnerConfig.builder()
                .fileFilterPattern(FileFilterPatterns.CK_FIELD)
                .bigQuery(RunnerConfig.BigQuery.builder()
                        .enabled(true)
                        .projectId(PROJECT_ID)
                        .datasetId(DATASET_ID)
                        .tableId("ck_field")
                        .build())
                .elasticSearch(RunnerConfig.ElasticSearch.builder()
                        .enabled(true)
                        .host(ELASTICSEARCH_HOST)
                        .port(ELASTICSEARCH_PORT)
                        .scheme(ELASTICSEARCH_SCHEME)
                        .index("ck_field")
                        .build())
                .build();
        new CkRunner<CkFieldCohesionSourceDto>(runnerConfig).run();
    }

    private static void runCkMethod() {
        RunnerConfig runnerConfig = RunnerConfig.builder()
                .fileFilterPattern(FileFilterPatterns.CK_METHOD)
                .bigQuery(RunnerConfig.BigQuery.builder()
                        .enabled(true)
                        .projectId(PROJECT_ID)
                        .datasetId(DATASET_ID)
                        .tableId("ck_method")
                        .build())
                .elasticSearch(RunnerConfig.ElasticSearch.builder()
                        .enabled(true)
                        .host(ELASTICSEARCH_HOST)
                        .port(ELASTICSEARCH_PORT)
                        .scheme(ELASTICSEARCH_SCHEME)
                        .index("ck_method")
                        .build())
                .build();
        new CkRunner<CkMethodCohesionSourceDto>(runnerConfig).run();
    }

    private static void runCkClass() {
        RunnerConfig runnerConfig = RunnerConfig.builder()
                .fileFilterPattern(FileFilterPatterns.CK_CLASS)
                .bigQuery(RunnerConfig.BigQuery.builder()
                        .enabled(true)
                        .projectId(PROJECT_ID)
                        .datasetId(DATASET_ID)
                        .tableId("ck_class")
                        .build())
                .elasticSearch(RunnerConfig.ElasticSearch.builder()
                        .enabled(true)
                        .host(ELASTICSEARCH_HOST)
                        .port(ELASTICSEARCH_PORT)
                        .scheme(ELASTICSEARCH_SCHEME)
                        .index("ck_class")
                        .build())
                .build();
        new CkRunner<CkClassCohesionSourceDto>(runnerConfig).run();
    }

    private static void runCkVariable() {
        RunnerConfig runnerConfig = RunnerConfig.builder()
                .fileFilterPattern(FileFilterPatterns.CK_VARIABLE)
                .bigQuery(RunnerConfig.BigQuery.builder()
                        .enabled(true)
                        .projectId(PROJECT_ID)
                        .datasetId(DATASET_ID)
                        .tableId("ck_variable")
                        .build())
                .elasticSearch(RunnerConfig.ElasticSearch.builder()
                        .enabled(true)
                        .host(ELASTICSEARCH_HOST)
                        .port(ELASTICSEARCH_PORT)
                        .scheme(ELASTICSEARCH_SCHEME)
                        .index("ck_variable")
                        .build())
                .build();
        new CkRunner<CkVariableCohesionSourceDto>(runnerConfig).run();
    }

//    public static void main(String[] args) throws Exception {
        //        List<FileFilterPattern> filterPatterns = List.of(FileFilterPatterns.CK_CLASS, FileFilterPatterns.CK_METHOD, FileFilterPatterns.CK_VARIABLE, FileFilterPatterns.CK_FIELD);
//        filterPatterns.stream().map(pattern -> new FileRichFilter().apply(pattern)).forEach(results -> {
//            for (FileFilterResult result : results) {
//                Object o = result.getExtractor().apply(result);
//                CohesionSourceDto<List<CkClassCohesionSourceDto>> cohesionSourceDto = (CohesionSourceDto<List<CkClassCohesionSourceDto>>) result.getExtractor().apply(result);
//                log.info("cohesionSourceDto: {}", cohesionSourceDto);
//            }
//        });

//        ExecutionEnvironment env = ExecutionEnvironment.getExecutionEnvironment();
//
//        // Set Akka ask timeout to 30 seconds
//        Configuration config = env.getConfiguration();
//        config.setString("akka.ask.timeout", "3000 s");
//        config.setString("web.timeout", "10000000");
//        DataSet<FileFilterResult> input = env.fromElements(new FileRichFilter().apply(FileFilterPatterns.CK_CLASS).toArray(new FileFilterResult[0]));
//        DataSet<CohesionSourceDto<List<CkFieldCohesionSourceDto>>> cohesionResults = input.map(new RichMapFunction<>() {
//            @Override
//            public CohesionSourceDto<List<CkFieldCohesionSourceDto>> map(FileFilterResult value) throws Exception {
//                return (CohesionSourceDto<List<CkFieldCohesionSourceDto>>) value.getExtractor().apply(value);
//            }
//        });
        // write cohesionResults to postgresql database
//        DataSet<Row> rows = cohesionResults
//                .flatMap((FlatMapFunction<CohesionSourceDto<List<CkFieldCohesionSourceDto>>, Row>) (value, out) -> value.getData().forEach(ckFieldCohesionSourceDto -> {
//                    String clazz = ckFieldCohesionSourceDto.getClazz();
//                    String method = ckFieldCohesionSourceDto.getMethod();
//                    String variable = ckFieldCohesionSourceDto.getVariable();
//                    String usage = ckFieldCohesionSourceDto.getUsage();
//                    out.collect(Row.of(clazz, method, variable, usage));
//                }))
//                .returns(new RowTypeInfo(Types.STRING, Types.STRING, Types.STRING, Types.STRING));
//        rows.output(JdbcOutputFormat.buildJdbcOutputFormat()
//                .setDrivername("org.postgresql.Driver")
//                .setDBUrl("jdbc:postgresql://localhost:5432/cohesion")
//                .setUsername("postgres")
//                .setPassword("postgres")
//                .setQuery("INSERT INTO ck_field (class, method, variable, usage) VALUES (?, ?, ?, ?)")
//                .finish());

//        cohesionResults.returns(new RowTypeInfo(Types.STRING, Types.STRING, Types.STRING, Types.STRING, Types.STRING))
        //
//        DataSet<List<FileFilterResult>> fileFilterResultDataSet = input.map((pattern) -> {
//            return new FileRichFilter().apply(pattern);
//        });
        // translate FileFilterResult to CohesionSourceDto
//        DataSet<CohesionSourceDto<List<CkClassCohesionSourceDto>>> cohesionSourceDto = fileFilterResultDataSet.map(results -> {
//            List<CohesionSourceDto> cohesionSourceDtos = new ArrayList<>();
//            for (FileFilterResult result : results) {
//                Object o = result.getExtractor().apply(result);
//                cohesionSourceDtos.add((CohesionSourceDto<List<CkClassCohesionSourceDto>>) result.getExtractor().apply(result));
//            }
//            return cohesionSourceDtos;
//        });
//        FlatMapOperator<FileFilterResult, CkClassDto> ckClassDtoFlatMapOperator = result.flatMap(new FlatMapFunction<FileFilterResult, CkClassDto>() {
//            @Override
//            public void flatMap(FileFilterResult file, Collector<CkClassDto> out) {
//
//                if (file.getFile().exists() && file.getFile().getName().equals("class.csv")) {
//                    CsvMapper csvMapper = new CsvMapper();
//                    CsvSchema schema = CsvSchema.emptySchema().withHeader();
//                    ObjectReader oReader = csvMapper.reader(CkClassDto.class).with(schema);
//                    try (Reader reader = new FileReader(file.getFile())) {
//                        MappingIterator<CkClassDto> mi = oReader.readValues(reader);
//                        while (mi.hasNext()) {
//                            CkClassDto current = mi.next();
//                            out.collect(current);
//                        }
//                    } catch (IOException e) {
//                        throw new RuntimeException(e);
//                    }
//                }
//            }
//        });
        // ckClassDtoFlatMapOperator to postgresql
//    }
}

package org.hsbc.lab.open.cohesion.config;

import lombok.Builder;
import lombok.Data;
import lombok.extern.jackson.Jacksonized;
import org.hsbc.lab.open.cohesion.util.pattern.FileFilterPattern;

@Data
@Builder
@Jacksonized
public class RunnerConfig {

    FileFilterPattern fileFilterPattern;
    BigQuery bigQuery;

    ElasticSearch elasticSearch;

    @Data
    @Builder
    @Jacksonized
    public static class ElasticSearch {
        Boolean enabled;
        String host;
        Integer port;
        String scheme;
        String index;
    }

    @Data
    @Builder
    @Jacksonized
    public static class BigQuery {
        Boolean enabled;
        String projectId;
        String datasetId;
        String tableId;
    }
}

package org.hsbc.lab.open.cohesion.domain.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Value
@Builder
@Jacksonized
public class CkClassCohesionSourceDto {
    // String fields: file,class,type,cbo,cboModified,fanin,fanout,wmc,dit,noc,rfc,lcom,lcom*,tcc,lcc,totalMethodsQty,staticMethodsQty,publicMethodsQty,privateMethodsQty,protectedMethodsQty,defaultMethodsQty,visibleMethodsQty,abstractMethodsQty,finalMethodsQty,synchronizedMethodsQty,totalFieldsQty,staticFieldsQty,publicFieldsQty,privateFieldsQty,protectedFieldsQty,defaultFieldsQty,finalFieldsQty,synchronizedFieldsQty,nosi,loc,returnQty,loopQty,comparisonsQty,tryCatchQty,parenthesizedExpsQty,stringLiteralsQty,numbersQty,assignmentsQty,mathOperationsQty,variablesQty,maxNestedBlocksQty,anonymousClassesQty,innerClassesQty,lambdasQty,uniqueWordsQty,modifiers,logStatementsQty
    String file;
    @JsonProperty("class")
    String clazz;
    String type;
    String cbo;
    String cboModified;
    String fanin;
    String fanout;
    String wmc;
    String dit;
    String noc;
    String rfc;
    String lcom;
    @JsonProperty("lcom*")
    String lcomSeries;
    String lcomStar;
    String tcc;
    String lcc;
    String totalMethodsQty;
    String staticMethodsQty;
    String publicMethodsQty;
    String privateMethodsQty;
    String protectedMethodsQty;
    String defaultMethodsQty;
    String visibleMethodsQty;
    String abstractMethodsQty;
    String finalMethodsQty;
    String synchronizedMethodsQty;
    String totalFieldsQty;
    String staticFieldsQty;
    String publicFieldsQty;
    String privateFieldsQty;
    String protectedFieldsQty;
    String defaultFieldsQty;
    String finalFieldsQty;
    String synchronizedFieldsQty;
    String nosi;
    String loc;
    String returnQty;
    String loopQty;
    String comparisonsQty;
    String tryCatchQty;
    String parenthesizedExpsQty;
    String stringLiteralsQty;
    String numbersQty;
    String assignmentsQty;
    String mathOperationsQty;
    String variablesQty;
    String maxNestedBlocksQty;
    String anonymousClassesQty;
    String innerClassesQty;
    String lambdasQty;
    String uniqueWordsQty;
    String modifiers;
    String logStatementsQty;
}

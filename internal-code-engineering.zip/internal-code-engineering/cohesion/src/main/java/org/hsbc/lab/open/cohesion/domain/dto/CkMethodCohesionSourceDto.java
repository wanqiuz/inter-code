package org.hsbc.lab.open.cohesion.domain.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Value
@Builder
@Jacksonized
public class CkMethodCohesionSourceDto {
    // String fields: file,class,method,constructor,line,cbo,cboModified,fanin,fanout,wmc,rfc,loc,returnsQty,variablesQty,parametersQty,methodsInvokedQty,methodsInvokedLocalQty,methodsInvokedIndirectLocalQty,loopQty,comparisonsQty,tryCatchQty,parenthesizedExpsQty,stringLiteralsQty,numbersQty,assignmentsQty,mathOperationsQty,maxNestedBlocksQty,anonymousClassesQty,innerClassesQty,lambdasQty,uniqueWordsQty,modifiers,logStatementsQty,hasJavaDoc
    @JsonProperty("file")
    String file;
    @JsonProperty("class")
    String clazz;
    String method;
    String constructor;
    String line;
    String cbo;
    String cboModified;
    String fanin;
    String fanout;
    String wmc;
    String rfc;
    String loc;
    String returnsQty;
    String variablesQty;
    String parametersQty;
    String methodsInvokedQty;
    String methodsInvokedLocalQty;
    String methodsInvokedIndirectLocalQty;
    String loopQty;
    String comparisonsQty;
    String tryCatchQty;
    String parenthesizedExpsQty;
    String stringLiteralsQty;

    String numbersQty;
    String assignmentsQty;
    String mathOperationsQty;
    String maxNestedBlocksQty;
    String anonymousClassesQty;
    String innerClassesQty;
    String lambdasQty;
    String uniqueWordsQty;
    String modifiers;
    String logStatementsQty;
    String hasJavaDoc;

}

package org.hsbc.lab.open.cohesion.domain.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Value
@Builder
@Jacksonized
public class CkVariableCohesionSourceDto {
    // String fields: file,class,method,variable,usage
    String file;
    @JsonProperty("class")
    String clazz;
    String method;
    String variable;
    String usage;
}

package org.hsbc.lab.open.cohesion.domain.dto;

import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Value
@Builder
@Jacksonized
public class CohesionSourceDto<T> {
    CohesionSourceMetaDto meta;
    T data;
}

package org.hsbc.lab.open.cohesion.domain.dto;

import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

import java.io.File;

@Value
@Builder
@Jacksonized
public class CohesionSourceMetaDto {
    String project;
    String module;
    String tool;
}

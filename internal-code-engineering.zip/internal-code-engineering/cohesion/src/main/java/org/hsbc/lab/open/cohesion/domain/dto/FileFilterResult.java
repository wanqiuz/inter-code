package org.hsbc.lab.open.cohesion.domain.dto;

import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

import java.io.File;
import java.util.function.Function;

@Value
@Builder
@Jacksonized
public class FileFilterResult {
    String project;
    String module;

    String tool;

    File file;
    Function extractor;
}

package org.hsbc.lab.open.cohesion.enums;

public enum ToolEnum {
    JPEEK,
    CK,
}

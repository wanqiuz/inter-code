package org.hsbc.lab.open.cohesion.migration;

public class InitTable {

}

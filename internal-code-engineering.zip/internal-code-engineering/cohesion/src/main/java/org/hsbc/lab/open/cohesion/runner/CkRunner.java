package org.hsbc.lab.open.cohesion.runner;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.cloud.bigquery.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpHost;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.common.xcontent.XContentType;
import org.hsbc.lab.open.cohesion.config.RunnerConfig;
import org.hsbc.lab.open.cohesion.domain.dto.CohesionSourceDto;
import org.hsbc.lab.open.cohesion.util.function.FileRichFilter;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
public class CkRunner<T> implements Runner {
    private static String DEFAULT_BIGQUERY_FIELD_NAME = "data";
    private ObjectMapper objectMapper;

    private RunnerConfig runnerConfig;

    public CkRunner(RunnerConfig runnerConfig) {
        this.runnerConfig = runnerConfig;
        objectMapper = new ObjectMapper();
    }

    @Override
    public void run() {
        List<CohesionSourceDto<List<T>>> cohesionSourceDto =
                new FileRichFilter().apply(runnerConfig.getFileFilterPattern())
                .stream()
                .map(result -> (CohesionSourceDto<List<T>>)result.getExtractor().apply(result))
                        .collect(Collectors.toList());

        // Write the data to BigQuery
        if (runnerConfig.getBigQuery().getEnabled()) {
            exportToBigQuery(cohesionSourceDto);
        }

        // Write the data to elastic search
        if (runnerConfig.getElasticSearch().getEnabled()) {
            exportToElasticSearch(cohesionSourceDto);
        }
    }

    private void exportToElasticSearch(List<CohesionSourceDto<List<T>>> cohesionSourceDto) {
        try (RestHighLevelClient client = new RestHighLevelClient(
                RestClient.builder(
                        new HttpHost(runnerConfig.getElasticSearch().getHost(),
                                runnerConfig.getElasticSearch().getPort(),
                                runnerConfig.getElasticSearch().getScheme())))) {
//            createElasticIndexIfNotExist(client, runnerConfig.getElasticSearch().getIndex());

            cohesionSourceDto.forEach(complexObject -> {
                try {
                    String jsonString = objectMapper.writeValueAsString(complexObject);
                    IndexRequest request = new IndexRequest(runnerConfig.getElasticSearch().getIndex());
                    request.source(jsonString, XContentType.JSON);
                    IndexResponse response = client.index(request, RequestOptions.DEFAULT);

                } catch (IOException e) {
                    log.error("Error while writing to elastic search： ", e);
                }
            });
        } catch (IOException e) {
            log.error("Error while writing to elastic search： ", e);
        }
    }

    private void exportToBigQuery(List<CohesionSourceDto<List<T>>> cohesionSourceDto) {
        BigQuery bigQuery = BigQueryOptions.getDefaultInstance().getService();
        TableId tableId = TableId.of(runnerConfig.getBigQuery().getProjectId(),
                runnerConfig.getBigQuery().getDatasetId(),
                runnerConfig.getBigQuery().getTableId());
        cohesionSourceDto.forEach(complexObject -> {
                    // Create row data
                    Map<String, Object> rowContent = new HashMap<>();
                    try {
                        rowContent.put(DEFAULT_BIGQUERY_FIELD_NAME, objectMapper.writeValueAsString(complexObject));
                    } catch (JsonProcessingException e) {
                        throw new RuntimeException(e);
                    }
                    // Set up the insert request
                    InsertAllRequest insertRequest = InsertAllRequest.newBuilder(tableId)
                            .addRow(rowContent)
                            .build();
                    InsertAllResponse insertResponse = bigQuery.insertAll(insertRequest);
                    if (insertResponse.hasErrors()) {
                        // Handle any errors that occurred during the insert operation
                        log.error("Error inserting data to BigQuery: {}", insertResponse.getInsertErrors());
                    }
                }
        );
    }

//    private void createElasticIndexIfNotExist(RestHighLevelClient client, String index) throws IOException {
//        GetIndexRequest getIndexRequest = new GetIndexRequest().indices(index);
//        boolean exists = client.indices().exists(getIndexRequest, RequestOptions.DEFAULT);
//
//        if (!exists) {
//            CreateIndexRequest createIndexRequest = new CreateIndexRequest(index);
//            // set mapping and settings if needed
//            client.indices().create(createIndexRequest, RequestOptions.DEFAULT);
//            log.info("Index " + index + " created.");
//        } else {
//            log.info("Index " + index + " already exists.");
//        }
//    }

}









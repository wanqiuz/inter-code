package org.hsbc.lab.open.cohesion.runner;

public interface Runner {
    void run();
}

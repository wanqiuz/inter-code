package org.hsbc.lab.open.cohesion.util.function;

import org.hsbc.lab.open.cohesion.domain.dto.FileFilterResult;
import org.hsbc.lab.open.cohesion.util.pattern.FileFilterPattern;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;

public class FileRichFilter implements Function<FileFilterPattern, List<FileFilterResult>> {

    @Override
    public List<FileFilterResult> apply(FileFilterPattern fileFilterPattern) {
        List<FileFilterResult> result = new ArrayList<>();

        File rootDirectory = new File(fileFilterPattern.getRootDirectoryName());
        if (!rootDirectory.exists() || !rootDirectory.isDirectory()) {
            return new ArrayList<>();
        }
        if (rootDirectory.listFiles() == null) {
            return new ArrayList<>();
        }
        for (File projectDirectory : Objects.requireNonNull(rootDirectory.listFiles())) {
            String projectName = projectDirectory.getName();
            if (projectName.equals(".DS_Store")) {
                continue;
            }
            File toolTargetDirectory = new File(projectDirectory, fileFilterPattern.getToolDir());
            if (toolTargetDirectory.exists() && toolTargetDirectory.isDirectory()) {
                File toolTargetFile = new File(toolTargetDirectory, fileFilterPattern.getFileName());
                if (toolTargetFile.exists() && !toolTargetFile.isDirectory()) {
                    result.add(FileFilterResult
                            .builder()
                            .project(projectName)
                            .module("")
                            .tool(fileFilterPattern.getTool())
                            .file(toolTargetFile)
                            .extractor(fileFilterPattern.getExtractor())
                            .build());
                }
            }

            if (projectDirectory.listFiles() == null) {
                continue;
            }
            // iterate modules if any (e.g. "module1", "module2")
            for (File moduleDirectory : Objects.requireNonNull(projectDirectory.listFiles())) {
                String moduleName = moduleDirectory.getName();
                File subToolTargetDirectory = new File(moduleDirectory, fileFilterPattern.getToolDir());
                if (subToolTargetDirectory.exists() && subToolTargetDirectory.isDirectory()) {
                    File subToolTargetFile = new File(subToolTargetDirectory, fileFilterPattern.getFileName());
                    if (subToolTargetFile.exists() && !subToolTargetFile.isDirectory()) {
                        result.add(FileFilterResult
                                .builder()
                                .project(projectName)
                                .module(moduleName)
                                .tool(fileFilterPattern.getTool())
                                .file(subToolTargetFile)
                                .extractor(fileFilterPattern.getExtractor())
                                .build());
                    }
                }
            }
        }

        return result;
    }
}

package org.hsbc.lab.open.cohesion.util.function.extractor;

import org.hsbc.lab.open.cohesion.domain.dto.FileFilterResult;
import org.hsbc.lab.open.cohesion.domain.dto.CkClassCohesionSourceDto;
import org.hsbc.lab.open.cohesion.domain.dto.CohesionSourceDto;

import java.util.List;
import java.util.function.Function;

public class CkClassCohesionSourceExtractor implements Function<FileFilterResult, CohesionSourceDto<List<CkClassCohesionSourceDto>>> {
    @Override
    public CohesionSourceDto<List<CkClassCohesionSourceDto>> apply(FileFilterResult fileFilterResult) {
        return new CsvCohesionSourceExtractor<CkClassCohesionSourceDto>().apply(CkClassCohesionSourceDto.class, fileFilterResult);
    }
}

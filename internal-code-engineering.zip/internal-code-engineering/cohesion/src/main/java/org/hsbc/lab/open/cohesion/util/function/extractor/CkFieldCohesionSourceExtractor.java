package org.hsbc.lab.open.cohesion.util.function.extractor;

import org.hsbc.lab.open.cohesion.domain.dto.CkFieldCohesionSourceDto;
import org.hsbc.lab.open.cohesion.domain.dto.CohesionSourceDto;
import org.hsbc.lab.open.cohesion.domain.dto.FileFilterResult;

import java.util.List;
import java.util.function.Function;

public class CkFieldCohesionSourceExtractor implements Function<FileFilterResult, CohesionSourceDto<List<CkFieldCohesionSourceDto>>> {
    @Override
    public CohesionSourceDto<List<CkFieldCohesionSourceDto>> apply(FileFilterResult fileFilterResult) {
        return new CsvCohesionSourceExtractor<CkFieldCohesionSourceDto>().apply(CkFieldCohesionSourceDto.class, fileFilterResult);
    }
}

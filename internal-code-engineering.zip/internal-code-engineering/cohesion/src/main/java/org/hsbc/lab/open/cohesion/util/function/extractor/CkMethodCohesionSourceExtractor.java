package org.hsbc.lab.open.cohesion.util.function.extractor;

import org.hsbc.lab.open.cohesion.domain.dto.*;

import java.util.List;
import java.util.function.Function;

public class CkMethodCohesionSourceExtractor implements Function<FileFilterResult, CohesionSourceDto<List<CkMethodCohesionSourceDto>>> {

    @Override
    public CohesionSourceDto<List<CkMethodCohesionSourceDto>> apply(FileFilterResult fileFilterResult) {
        return new CsvCohesionSourceExtractor<CkMethodCohesionSourceDto>().apply(CkMethodCohesionSourceDto.class, fileFilterResult);
    }
}

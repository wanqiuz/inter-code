package org.hsbc.lab.open.cohesion.util.function.extractor;

import org.hsbc.lab.open.cohesion.domain.dto.CkClassCohesionSourceDto;
import org.hsbc.lab.open.cohesion.domain.dto.CkVariableCohesionSourceDto;
import org.hsbc.lab.open.cohesion.domain.dto.CohesionSourceDto;
import org.hsbc.lab.open.cohesion.domain.dto.FileFilterResult;

import java.util.List;
import java.util.function.Function;

public class CkVariableCohesionSourceExtractor implements Function<FileFilterResult, CohesionSourceDto<List<CkVariableCohesionSourceDto>>> {
    @Override
    public CohesionSourceDto<List<CkVariableCohesionSourceDto>> apply(FileFilterResult fileFilterResult) {
        return new CsvCohesionSourceExtractor<CkVariableCohesionSourceDto>().apply(CkVariableCohesionSourceDto.class, fileFilterResult);
    }
}

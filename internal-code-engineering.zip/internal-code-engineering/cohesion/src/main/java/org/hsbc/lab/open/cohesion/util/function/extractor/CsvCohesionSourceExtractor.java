package org.hsbc.lab.open.cohesion.util.function.extractor;

import com.fasterxml.jackson.databind.MappingIterator;
import com.fasterxml.jackson.databind.ObjectReader;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;
import org.hsbc.lab.open.cohesion.domain.dto.CkClassCohesionSourceDto;
import org.hsbc.lab.open.cohesion.domain.dto.CohesionSourceDto;
import org.hsbc.lab.open.cohesion.domain.dto.CohesionSourceMetaDto;
import org.hsbc.lab.open.cohesion.domain.dto.FileFilterResult;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BiFunction;
import java.util.function.Function;

public class CsvCohesionSourceExtractor<T> implements BiFunction<Class<T>, FileFilterResult, CohesionSourceDto<List<T>>> {
    @Override
    public CohesionSourceDto<List<T>> apply(Class<T> clazz, FileFilterResult fileFilterResult) {
        List<T> result = new ArrayList<>();
        File file = fileFilterResult.getFile();
        CsvMapper csvMapper = new CsvMapper();
        CsvSchema schema = CsvSchema.emptySchema().withHeader();
        ObjectReader oReader = csvMapper.readerFor(clazz).with(schema);
        try (Reader reader = new FileReader(file)) {
            MappingIterator<T> mi = oReader.readValues(reader);
            while (mi.hasNext()) {
                T current = mi.next();
                result.add(current);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return CohesionSourceDto.<List<T>>builder()
                .meta(CohesionSourceMetaDto
                        .builder()
                        .project(fileFilterResult.getProject())
                        .module(fileFilterResult.getModule())
                        .tool(fileFilterResult.getTool())
                        .build())
                .data(result)
                .build();
    }
}

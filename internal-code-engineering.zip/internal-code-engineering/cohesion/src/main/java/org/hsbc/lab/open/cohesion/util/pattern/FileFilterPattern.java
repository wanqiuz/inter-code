package org.hsbc.lab.open.cohesion.util.pattern;

import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

import java.util.function.Function;

@Value
@Builder
@Jacksonized
public class FileFilterPattern {
    String rootDirectoryName;
    String tool;
    String toolDir;
    String fileName;
    Function extractor;
}

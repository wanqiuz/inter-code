package org.hsbc.lab.open.cohesion.util.pattern;

import org.hsbc.lab.open.cohesion.util.function.extractor.CkClassCohesionSourceExtractor;
import org.hsbc.lab.open.cohesion.util.function.extractor.CkFieldCohesionSourceExtractor;
import org.hsbc.lab.open.cohesion.util.function.extractor.CkMethodCohesionSourceExtractor;
import org.hsbc.lab.open.cohesion.util.function.extractor.CkVariableCohesionSourceExtractor;

public class FileFilterPatterns {
    // get value from environment variable
    private static final String ROOT_DIRECTORY_NAME = System.getenv("ROOT_DIRECTORY_NAME") == null ? "data" : System.getenv("ROOT_DIRECTORY_NAME");

    public static final FileFilterPattern CK_METHOD = FileFilterPattern.builder()
            .rootDirectoryName(ROOT_DIRECTORY_NAME)
            .tool("CK")
            .toolDir("csv")
            .fileName("method.csv")
            .extractor(new CkMethodCohesionSourceExtractor())
            .build();

    public static final FileFilterPattern CK_CLASS = FileFilterPattern.builder()
            .rootDirectoryName(ROOT_DIRECTORY_NAME)
            .tool("CK")
            .toolDir("csv")
            .fileName("class.csv")
            .extractor(new CkClassCohesionSourceExtractor())
            .build();

    public static final FileFilterPattern CK_VARIABLE = FileFilterPattern.builder()
            .rootDirectoryName(ROOT_DIRECTORY_NAME)
            .tool("CK")
            .toolDir("csv")
            .fileName("variable.csv")
            .extractor(new CkVariableCohesionSourceExtractor())
            .build();

    public static final FileFilterPattern CK_FIELD = FileFilterPattern.builder()
            .rootDirectoryName(ROOT_DIRECTORY_NAME)
            .tool("CK")
            .toolDir("csv")
            .fileName("field.csv")
            .extractor(new CkFieldCohesionSourceExtractor())
            .build();
}

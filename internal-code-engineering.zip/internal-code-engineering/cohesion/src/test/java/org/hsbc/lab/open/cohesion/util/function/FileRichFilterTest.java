package org.hsbc.lab.open.cohesion.util.function;

import org.hsbc.lab.open.cohesion.domain.dto.*;
import org.hsbc.lab.open.cohesion.util.function.extractor.CkClassCohesionSourceExtractor;
import org.hsbc.lab.open.cohesion.util.function.extractor.CkFieldCohesionSourceExtractor;
import org.hsbc.lab.open.cohesion.util.function.extractor.CkMethodCohesionSourceExtractor;
import org.hsbc.lab.open.cohesion.util.function.extractor.CkVariableCohesionSourceExtractor;
import org.hsbc.lab.open.cohesion.util.pattern.FileFilterPattern;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

public class FileRichFilterTest {

    @Test
    public void testCkClass() {
        FileFilterPattern fileFilterPattern = FileFilterPattern.builder()
                .rootDirectoryName(getAbsolutePathFromResource("data"))
                .tool("ck")
                .toolDir("csv")
                .fileName("class.csv")
                .extractor(new CkClassCohesionSourceExtractor())
                .build();
        List<FileFilterResult> fileFilterResults = new FileRichFilter().apply(fileFilterPattern);
        Assertions.assertEquals(3, fileFilterResults.size(), "fileFilterResults should have 3 elements");
        for (FileFilterResult fileFilterResult : fileFilterResults) {
            CohesionSourceDto<List<CkClassCohesionSourceDto>> cohesionSourceDto = (CohesionSourceDto<List<CkClassCohesionSourceDto>>)fileFilterPattern.getExtractor().apply(fileFilterResult);
            Assertions.assertEquals(24, cohesionSourceDto.getData().size(), "CkClassCohesionSourceDto should have 24 elements");
        }
    }

    @Test
    public void testCkMethod() {
        FileFilterPattern fileFilterPattern = FileFilterPattern.builder()
                .rootDirectoryName(getAbsolutePathFromResource("data"))
                .tool("ck")
                .toolDir("csv")
                .fileName("method.csv")
                .extractor(new CkMethodCohesionSourceExtractor())
                .build();
        List<FileFilterResult> fileFilterResults = new FileRichFilter().apply(fileFilterPattern);
        Assertions.assertEquals(3, fileFilterResults.size(), "fileFilterResults should have 3 elements");
        for (FileFilterResult fileFilterResult : fileFilterResults) {
            CohesionSourceDto<List<CkMethodCohesionSourceDto>> cohesionSourceDto = (CohesionSourceDto<List<CkMethodCohesionSourceDto>>)fileFilterPattern.getExtractor().apply(fileFilterResult);
            Assertions.assertEquals(334, cohesionSourceDto.getData().size(), "CkMethodCohesionSourceExtractor should have 24 elements");
        }
    }

    @Test
    public void testCkVariable() {
        FileFilterPattern fileFilterPattern = FileFilterPattern.builder()
                .rootDirectoryName(getAbsolutePathFromResource("data"))
                .tool("ck")
                .toolDir("csv")
                .fileName("variable.csv")
                .extractor(new CkVariableCohesionSourceExtractor())
                .build();
        List<FileFilterResult> fileFilterResults = new FileRichFilter().apply(fileFilterPattern);
        Assertions.assertEquals(3, fileFilterResults.size(), "fileFilterResults should have 3 elements");
        for (FileFilterResult fileFilterResult : fileFilterResults) {
            CohesionSourceDto<List<CkVariableCohesionSourceDto>> cohesionSourceDto = (CohesionSourceDto<List<CkVariableCohesionSourceDto>>)fileFilterPattern.getExtractor().apply(fileFilterResult);
            Assertions.assertEquals(668, cohesionSourceDto.getData().size(), "CkVariableCohesionSourceDto should have 668 elements");
        }
    }

    @Test
    public void testCkField() {
        FileFilterPattern fileFilterPattern = FileFilterPattern.builder()
                .rootDirectoryName(getAbsolutePathFromResource("data"))
                .tool("ck")
                .toolDir("csv")
                .fileName("field.csv")
                .extractor(new CkFieldCohesionSourceExtractor())
                .build();
        List<FileFilterResult> fileFilterResults = new FileRichFilter().apply(fileFilterPattern);
        Assertions.assertEquals(3, fileFilterResults.size(), "fileFilterResults should have 3 elements");
        for (FileFilterResult fileFilterResult : fileFilterResults) {
            CohesionSourceDto<List<CkFieldCohesionSourceDto>> cohesionSourceDto = (CohesionSourceDto<List<CkFieldCohesionSourceDto>>)fileFilterPattern.getExtractor().apply(fileFilterResult);
            Assertions.assertEquals(380, cohesionSourceDto.getData().size(), "CkFieldCohesionSourceDto should have 380 elements");
        }
    }


    public String getAbsolutePathFromResource(String resourceFileDirectory){
        ClassLoader classLoader = getClass().getClassLoader();
        URL resourceUrl = classLoader.getResource(resourceFileDirectory);
        if (resourceUrl == null) {
            throw new IllegalArgumentException("File not found: " + resourceFileDirectory);
        }
        try {
            Path resourcePath = Paths.get(resourceUrl.toURI());
            return resourcePath.toAbsolutePath().toString();
        } catch (URISyntaxException e) {
            throw new IllegalArgumentException("Invalid URI syntax for file: " + resourceFileDirectory, e);
        }
    }

}